// PUSH - Responsive App Component
import { useEffect, useRef } from 'react';
import Markdown from 'react-markdown';
import { useStore } from './store';
import { useInitData, useChat, useWallet, useAutoScroll } from './hooks';
import { formatAddress } from './utils/api';

export default function App() {
  useInitData();
  const { sidebarOpen, setSidebarOpen } = useStore();

  return (
    <div className="app-container">
      <Header onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
      <div className="main-layout">
        <Sidebar />
        <MobileSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <div className={`sidebar-overlay ${sidebarOpen ? 'open' : ''}`} onClick={() => setSidebarOpen(false)} />
        <main className="main-content">
          <ChatArea />
        </main>
      </div>
      <Footer />
    </div>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-left">
          <a href="https://www.x402hackathon.com/" target="_blank" rel="noopener noreferrer" className="footer-badge">
            <span className="footer-badge-icon">◎</span>
            <span className="footer-badge-text">x402 HACKATHON</span>
          </a>
          <span className="footer-divider">•</span>
          <span className="footer-subtitle">Built for the next era of internet-native payments</span>
        </div>
        <div className="footer-right">
          <a href="https://x.com/privacy_maxi" target="_blank" rel="noopener noreferrer" className="footer-social">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
            </svg>
            <span>@privacy_maxi</span>
          </a>
        </div>
      </div>
    </footer>
  );
}

function Header({ onMenuClick }: { onMenuClick: () => void }) {
  const { health } = useStore();
  const { wallet, connect, disconnect } = useWallet();

  return (
    <header className="header">
      <div className="header-left">
        <button onClick={onMenuClick} className="menu-btn">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <div className="logo">
          <div className="logo-icon">P</div>
          <span className="logo-text">PUSH</span>
        </div>
      </div>

      <div className="header-stats">
        {health && (
          <>
            <span className="flex items-center gap-1"><span className="status-dot" /> ONLINE</span>
            <span>{health.toolCount} TOOLS</span>
            <span>{health.networkCount} NETWORKS</span>
            <span>{health.payment.price} / REQ</span>
          </>
        )}
      </div>

      <div>
        {wallet.isConnected ? (
          <div className="wallet-display">
            <span className="wallet-addr">{formatAddress(wallet.address!)}</span>
            <button onClick={disconnect} className="btn-disconnect">DISCONNECT</button>
          </div>
        ) : (
          <button onClick={connect} disabled={wallet.isConnecting} className="btn-connect">
            {wallet.isConnecting ? 'CONNECTING...' : 'CONNECT WALLET'}
          </button>
        )}
      </div>
    </header>
  );
}

function SidebarContent({ onAction }: { onAction?: () => void }) {
  const { health, networks, selectedNetwork, setSelectedNetwork, gasPrices, setInputValue } = useStore();

  const quickActions = [
    "What's the ETH price?",
    "Show Fear & Greed Index",
    "Gas prices on Base",
    "Top DeFi protocols",
    "Analyze vitalik.eth",
  ];

  return (
    <>
      <div className="sidebar-section">
        <div className="sidebar-title">Networks</div>
        <div className="network-grid">
          {Object.entries(networks).map(([key, network]) => (
            <button
              key={key}
              onClick={() => setSelectedNetwork(key)}
              className={`network-btn ${selectedNetwork === key ? 'active' : ''}`}
            >
              {network.shortName}
            </button>
          ))}
        </div>
      </div>

      {gasPrices[selectedNetwork] && (
        <div className="sidebar-section">
          <div className="sidebar-title">Gas ({networks[selectedNetwork]?.shortName})</div>
          <div className="gas-grid">
            <div className="gas-item">
              <div className="gas-value">{parseFloat(gasPrices[selectedNetwork].standard).toFixed(1)}</div>
              <div className="gas-label">STD</div>
            </div>
            <div className="gas-item">
              <div className="gas-value">{parseFloat(gasPrices[selectedNetwork].fast).toFixed(1)}</div>
              <div className="gas-label">FAST</div>
            </div>
            <div className="gas-item">
              <div className="gas-value">{parseFloat(gasPrices[selectedNetwork].instant).toFixed(1)}</div>
              <div className="gas-label">INST</div>
            </div>
          </div>
        </div>
      )}

      <div className="sidebar-section" style={{ flex: 1 }}>
        <div className="sidebar-title">Quick Actions</div>
        {quickActions.map((action, i) => (
          <button key={i} onClick={() => { setInputValue(action); onAction?.(); }} className="quick-action">
            → {action}
          </button>
        ))}
      </div>

      {health && (
        <div className="sidebar-section">
          <div className="sidebar-title">Tools ({health.toolCount})</div>
          <div className="tools-list">
            {health.tools.slice(0, 10).map((tool) => (
              <span key={tool} className="tool-badge">{tool}</span>
            ))}
            {health.tools.length > 10 && (
              <span className="tool-badge">+{health.tools.length - 10} more</span>
            )}
          </div>
        </div>
      )}

      <div className="sidebar-footer">PUSH v2.0 • x402</div>
    </>
  );
}

function Sidebar() {
  return <aside className="sidebar"><SidebarContent /></aside>;
}

function MobileSidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <div className={`sidebar-mobile ${open ? 'open' : ''}`}>
      <button onClick={onClose} className="sidebar-close">×</button>
      <SidebarContent onAction={onClose} />
    </div>
  );
}

function ChatArea() {
  const { messages } = useStore();
  return messages.length === 0 ? <WelcomeScreen /> : <ChatView />;
}

function WelcomeScreen() {
  const { health, setInputValue } = useStore();
  const { wallet } = useWallet();

  const features = [
    { icon: '◈', title: 'PRICE DATA' },
    { icon: '◇', title: 'WALLETS' },
    { icon: '△', title: 'DEFI' },
    { icon: '○', title: 'NFTS' },
    { icon: '□', title: 'GAS' },
    { icon: '▽', title: 'CONTRACTS' },
  ];

  const suggestions = [
    "ETH price?",
    "Analyze vitalik.eth",
    "Top DeFi protocols",
    "Fear & Greed",
    "Gas on Arbitrum",
    "Trending tokens",
  ];

  return (
    <div className="welcome-screen">
      <div className="welcome-hero">
        <div className="welcome-logo">
          <span className="welcome-logo-text">P</span>
        </div>
        <h1 className="welcome-title">PUSH</h1>
        <p className="welcome-subtitle">AI-POWERED BLOCKCHAIN INTELLIGENCE</p>
        <p className="welcome-subtitle">30+ TOOLS • 7 NETWORKS • x402</p>
        {!wallet.isConnected && (
          <div className="welcome-hint">CONNECT WALLET TO PAY WITH USDC</div>
        )}
      </div>

      <div className="features-grid">
        {features.map((f, i) => (
          <div key={i} className="feature-card">
            <div className="feature-icon">{f.icon}</div>
            <div className="feature-title">{f.title}</div>
          </div>
        ))}
      </div>

      <div className="suggestions-grid">
        {suggestions.map((s, i) => (
          <button key={i} onClick={() => setInputValue(s)} className="suggestion-btn">{s}</button>
        ))}
      </div>

      <ChatInput />

      {health && (
        <div className="networks-row" style={{ marginTop: '0.5rem' }}>
          {health.networks.map((n) => (
            <span key={n} className="network-badge">{n.toUpperCase()}</span>
          ))}
        </div>
      )}
    </div>
  );
}

function ChatView() {
  const { messages, clearMessages } = useStore();
  const scrollRef = useAutoScroll(messages);

  return (
    <div className="chat-container">
      <div className="chat-messages" ref={scrollRef}>
        {messages.map((msg) => (
          <Message key={msg.id} message={msg} />
        ))}
      </div>
      <ChatInput />
      {messages.length > 0 && (
        <button onClick={clearMessages} className="clear-btn">CLEAR</button>
      )}
    </div>
  );
}

function Message({ message }: { message: import('./store').Message }) {
  return (
    <div className="message">
      <div className="message-header">
        <span className="message-role">{message.role === 'user' ? 'YOU' : 'PUSH'}</span>
        <span className="message-time">{message.timestamp.toLocaleTimeString()}</span>
      </div>
      <div className="message-content">
        {message.content ? (
          <Markdown
            components={{
              strong: ({ children }) => <strong>{children}</strong>,
              code: ({ children }) => <code>{children}</code>,
              p: ({ children }) => <p>{children}</p>,
              ul: ({ children }) => <ul>{children}</ul>,
              ol: ({ children }) => <ol>{children}</ol>,
              li: ({ children }) => <li>{children}</li>,
            }}
          >
            {message.content}
          </Markdown>
        ) : message.isStreaming ? (
          <span className="loading-dots">Processing</span>
        ) : null}
      </div>
      {message.toolsUsed && message.toolsUsed.length > 0 && (
        <div className="message-tools">
          <div className="message-tools-label">TOOLS USED</div>
          <div className="message-tools-list">
            {message.toolsUsed.map((t, i) => (
              <span key={i} className="tool-badge">{t}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ChatInput() {
  const { inputValue, setInputValue, isLoading } = useStore();
  const { sendChatMessage } = useChat();
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = () => {
    if (inputValue.trim() && !isLoading) {
      sendChatMessage(inputValue);
      setInputValue('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = Math.min(inputRef.current.scrollHeight, 100) + 'px';
    }
  }, [inputValue]);

  return (
    <div className="chat-input-container">
      <div className="chat-input-row">
        <textarea
          ref={inputRef}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask about blockchain data..."
          disabled={isLoading}
          rows={1}
          className="chat-input"
        />
        <button onClick={handleSubmit} disabled={!inputValue.trim() || isLoading} className="btn-send">
          {isLoading ? '...' : 'SEND'}
        </button>
      </div>
      <div className="chat-input-hint">
        <span>SHIFT+ENTER for new line</span>
        <span>CLAUDE SONNET</span>
      </div>
    </div>
  );
}
